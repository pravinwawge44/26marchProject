package com.example.eattendance;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;

import android.nfc.FormatException;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.nfc.tech.Ndef;
import android.os.Bundle;
import android.os.StrictMode;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Paint.Join;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TimePicker;
import android.widget.Toast;

public class AttendanceActivity extends Activity {

	NfcAdapter adapter;
	PendingIntent pendingIntent;
	IntentFilter writeTagFilters[];
	boolean writeMode;
	Tag mytag;
	Context ctx;
	ArrayList students = new ArrayList();

	String teacher_id;
	String lecture_id;
	String lecture_name;
	int hour;

	TimePicker timePicker1=null;
	//	HashMap< String, String> param = new HashMap<String, String>();
	HashMap< String, String> param=null;
	protected String time;
	String user_id;
	@Override

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
		StrictMode.setThreadPolicy(policy);

		ctx = this;
		setContentView(R.layout.activity_attendance);

		lecture_id = getIntent().getStringExtra("list");
		user_id = getIntent().getStringExtra("userid");
		System.out.println("teacher id ="+user_id);
		timePicker1 = (((TimePicker) findViewById(R.id.timePicker1)));
		System.out.println("timePicker ="+timePicker1);

		adapter = NfcAdapter.getDefaultAdapter(this);
		System.out.println("timePicker ="+ adapter);
		pendingIntent = PendingIntent.getActivity(this, 0, new Intent(this, getClass()).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), 0);
		IntentFilter tagDetected = new IntentFilter(NfcAdapter.ACTION_TAG_DISCOVERED);
		tagDetected.addCategory(Intent.CATEGORY_DEFAULT);
		writeTagFilters = new IntentFilter[] { tagDetected };


		Button startAttendnce = (Button) findViewById(R.id.bt_start);
		startAttendnce.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				time = timePicker1.getCurrentHour()+":"+timePicker1.getCurrentMinute();
				students = new ArrayList<String>();
			}
		});
		Button stopAttendnce = (Button) findViewById(R.id.bt_stop);
		stopAttendnce.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				System.out.println("Inside item click attendance");
				HashMap<String, String> param= new HashMap<String, String>();
				param.put("lecture_id", lecture_id);
				param.put("roll_number", students.toString().replaceAll("[\\s\\[\\]]", ""));
				param.put("teacher_id", user_id);
				param.put("lecture_time", time);

				Network.connect("http://" + Network.IP
				+ "/eattendance/attendances/set_attendance", param);
				System.out.println("parameter" + param);
				Intent intent = new  Intent(AttendanceActivity.this, LoginActivity.class);
				//				

				startActivity(intent);
			}
		});

	}

	private void read(Tag tag){
		StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
		StrictMode.setThreadPolicy(policy);
		// Get an instance of Ndef for the tag.
		Ndef ndef = Ndef.get(tag);
		// Enable I/O
		try {
			ndef.connect();
			// read the message
			NdefMessage ndefMessage = ndef.getCachedNdefMessage();
			NdefRecord[] ndefRecords = ndefMessage.getRecords();
			String user_id="";

			for (NdefRecord ndefRecord : ndefRecords) {
				user_id+=readText(ndefRecord);
			}
			System.out.println("message:"+user_id);
			// Close the connection
			ndef.close();
			if(!students.contains(user_id)){
				students.add(user_id);
			}

			Toast.makeText(ctx, "Current Student Count:"+students.size(), Toast.LENGTH_SHORT).show();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}	 



	private String readText(NdefRecord record) throws UnsupportedEncodingException {

		/*
		 * See NFC forum specification for "Text Record Type Definition" at 3.2.1
		 *
		 * http://www.nfc-forum.org/specs/
		 *
		 * bit_7 defines encoding
		 * bit_6 reserved for future use, must be 0
		 * bit_5..0 length of IANA language code
		 */
		byte[] payload = record.getPayload();
		// Get the Text Encoding
		String textEncoding = ((payload[0] & 128) == 0) ? "UTF-8" : "UTF-16";
		// Get the Language Code
		int languageCodeLength = payload[0] & 0063;
		// String languageCode = new String(payload, 1, languageCodeLength, "US-ASCII");
		// e.g. "en"
		// Get the Text
		return new String(payload, languageCodeLength + 1, payload.length - languageCodeLength - 1, textEncoding);

	}





	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.attendance, menu);
		return true;
	}

	protected void onNewIntent(Intent intent){
		StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
		StrictMode.setThreadPolicy(policy);

		if(NfcAdapter.ACTION_TAG_DISCOVERED.equals(intent.getAction())){
			mytag = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);    
			Toast.makeText(this, "Tag detected:", Toast.LENGTH_SHORT ).show();

			read(mytag);
		}}

	@Override
	public void onPause(){
		super.onPause();
		WriteModeOff();
	}

	@Override
	public void onResume(){
		super.onResume();
		WriteModeOn();
	}

	private void WriteModeOn(){
		writeMode = true;
		adapter.enableForegroundDispatch(this, pendingIntent, writeTagFilters, null);
	}

	private void WriteModeOff(){
		writeMode = false;
		adapter.disableForegroundDispatch(this);
	}
}


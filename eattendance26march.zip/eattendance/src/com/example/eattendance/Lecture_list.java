package com.example.eattendance;

import android.os.Bundle;
import java.util.*;
import android.app.Activity;
import android.view.Menu;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.HashMap;
import android.os.Bundle;
import android.os.StrictMode;
import android.app.Activity;
import android.app.ListActivity;
import android.content.Context;
import android.content.Intent;
//import android.support.v4.widget.ListViewAutoScrollHelper;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.*;

public class Lecture_list extends Activity {
	private String user_id;
	private String list;

	stableArrayAdapter adapter;
	ListView lstView; 
	ArrayList<String> Target = new ArrayList<String>();
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_lecture_list);
		Toast.makeText(Lecture_list.this, "in the lectures list" , Toast.LENGTH_SHORT).show();
		user_id = getIntent().getStringExtra("userid");
		list = getIntent().getStringExtra("list");
		System.out.println("    list  **** "+      list);
		lstView = (ListView) findViewById(R.id.lectureList);
		lstView.setChoiceMode(ListView.CHOICE_MODE_SINGLE);        
		lstView.setTextFilterEnabled(true);

		String[] separated = list.split(",");
		for (int i = 0; i < separated.length; i++) {
			String[] sections=separated[i].split("-");
			Target.add(sections[1]);
			System.out.println("    separated[i]"+      separated[i]);	
		}

		adapter = new stableArrayAdapter(this,android.R.layout.simple_list_item_checked, Target);
		

		lstView.setAdapter(adapter);
		adapter.notifyDataSetChanged();
		lstView.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int position,
					long arg3) {
				System.out.println("Inside item click");
				// TODO Auto-generated method stub
				String lecture = (String) lstView.getItemAtPosition(position);
				String[] separated = lecture.split("-");

				StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
				StrictMode.setThreadPolicy(policy);

			
				lstView.setVisibility(View.GONE);
				Intent intent = new  Intent(Lecture_list.this, ListViewCheckboxesActivity.class);
				intent.putExtra("userid", user_id);
				intent.putExtra("list", separated[0]);
				startActivity(intent);
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.lecture_list, menu);
		return true;
	}




class stableArrayAdapter extends ArrayAdapter<String> {


	public stableArrayAdapter(Context context, int textViewResourceId, ArrayList<String> target) 
	{
		super(context, textViewResourceId, target);

	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return Target.size();
	}

	@Override
	public String getItem(int position) {
		// TODO Auto-generated method stub
		return Target.get(position);
	}

	@Override
	public int getPosition(String item) {
		// TODO Auto-generated method stub
		return super.getPosition(item);
	}

	@Override
	public boolean hasStableIds() {
		return true;
	}

} 
}


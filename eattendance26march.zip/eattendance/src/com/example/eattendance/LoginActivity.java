package com.example.eattendance;

import java.util.HashMap;

import android.os.Bundle;
import android.os.StrictMode;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends Activity {
	private EditText et_username;
	private EditText et_password;	
	private Button bt_login;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login);
		et_username = (EditText) findViewById(R.id.et_username);
		et_password = (EditText) findViewById(R.id.et_password);
		 bt_login =(Button) findViewById(R.id.bt_login1);
		 StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
			StrictMode.setThreadPolicy(policy);
			
			Thread thread =new Thread()
			{
				
			  public void run(){
				  try{
			bt_login.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					System.out.println("  hi in the login button event ");
					String username = String.valueOf(et_username.getText());
					// Stores Password
					String password = String.valueOf(et_password.getText());  
					// Validates the User name and Password for admin, admin
					HashMap< String, String> param = new HashMap<String, String>();
					param.put("username", username);
					param.put("password", password);
					System.out.println("  before sending values to network.java     ");
//					String list=Network.connect("http://192.168.2.180/eattendance/lectures/get_lectures_list", param);
					String list=Network.connect("http://" + Network.IP + "/eattendance/teachers/login", param);
					list=list.trim();
					if (list.equals("0")) {
					//et_username.setText("Login Unsuccessful!"+list);
						Toast.makeText(getApplicationContext(),
								"login Unsuccessfull", Toast.LENGTH_LONG)
								.show();
					} 
					
					if (!list.equals("0"))
					{
						Intent intent = new  Intent(LoginActivity.this, Lecture_list.class);
						System.out.println(" list   "+list);
						String list2[]=list.split("~");
						
						System.out.println("   "+list2[0]);
						intent.putExtra("userid", list2[0]);
						intent.putExtra("list", list2[1]);
						startActivity(intent);
						
					}
					
				}
			});
				  }
				  catch(Exception e)
				  {
					e.printStackTrace();  
				  }
				}
		};
		thread.start();		  
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.login, menu);
		return true;
	}

}

package com.example.eattendance;

import com.example.eattendance.Lecture_list;
import com.example.eattendance.MainActivity;
//import com.example.evoting.R;
import com.example.eattendance.RegisterActivity;

import android.os.Bundle;
import android.os.StrictMode;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class MainActivity extends Activity {

	@Override
	
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
		StrictMode.setThreadPolicy(policy);

		Button register =(Button) findViewById(R.id.bt_register);
		register.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				String list = Network.connect("http://" + Network.IP
				+ "/eattendance/students/get_student_list", null);
				Intent intent = new Intent(MainActivity.this, RegisterActivity.class);
				intent.putExtra("list", list);
				MainActivity.this.startActivity(intent);
			}
		});
	   
		
		Button login =(Button) findViewById(R.id.bt_login);
		login.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(MainActivity.this, LoginActivity.class);
				MainActivity.this.startActivity(intent);
			}
		});
		
	}

	

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}

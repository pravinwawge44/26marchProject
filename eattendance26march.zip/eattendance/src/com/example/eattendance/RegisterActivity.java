package com.example.eattendance;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.nfc.FormatException;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.nfc.tech.Ndef;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

public class RegisterActivity extends Activity {

	private String student_list;
	NfcAdapter adapter;
	PendingIntent pendingIntent;
	IntentFilter writeTagFilters[];
	boolean writeMode;
	Tag mytag;
	Context ctx;
	
	stableArrayAdapter adapter2;
	ListView lstView; 
	ArrayList<String> Target = new ArrayList<String>();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_register);
		StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
		StrictMode.setThreadPolicy(policy);

		student_list = getIntent().getStringExtra("list");

		ctx=this;
		final String message = this.student_list;
		

		adapter = NfcAdapter.getDefaultAdapter(this);
		pendingIntent = PendingIntent.getActivity(this, 0, new Intent(this, getClass()).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), 0);
		IntentFilter tagDetected = new IntentFilter(NfcAdapter.ACTION_TAG_DISCOVERED);
		tagDetected.addCategory(Intent.CATEGORY_DEFAULT);
		writeTagFilters = new IntentFilter[] { tagDetected };
		
		lstView = (ListView) findViewById(R.id.studentList);
		lstView.setChoiceMode(ListView.CHOICE_MODE_SINGLE);        
		lstView.setTextFilterEnabled(true);
		
		System.out.println("list:"+student_list);
		student_list=student_list.trim();
		String[] separated = student_list.split(",");
		for (int i = 0; i < separated.length; i++) {
			Target.add(separated[i]);
		}

		adapter2 = new stableArrayAdapter(this,android.R.layout.simple_list_item_checked, Target);

		lstView.setAdapter(adapter2);
		adapter2.notifyDataSetChanged();
		lstView.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int position,
					long arg3) {
				// TODO Auto-generated method stub
				String candidate = (String) lstView.getItemAtPosition(position);
				String[] separated = candidate.split("-");
				
				StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
				StrictMode.setThreadPolicy(policy);
				
				HashMap<String, String> param = new HashMap<String, String>();
				param.put("id", separated[0]);
				String msg=separated[0];

				try {
					if(mytag==null){
						Toast.makeText(ctx, "Tag is null", Toast.LENGTH_LONG ).show();
					}else{
						if(student_list==null){
							Toast.makeText(ctx,"User id is null", Toast.LENGTH_SHORT ).show();
						}else{
//							write(message.toString(),mytag);
							write(msg.toString(),mytag);
							Toast.makeText(ctx,"Done", Toast.LENGTH_LONG ).show();
							Intent intent = new  Intent(RegisterActivity.this, LoginActivity.class);
							
							startActivity(intent);
						}
					}
				} catch (IOException e) {
					Toast.makeText(ctx, "err", Toast.LENGTH_LONG ).show();
					e.printStackTrace();
				} catch (FormatException e) {
					Toast.makeText(ctx,"err", Toast.LENGTH_LONG ).show();
					e.printStackTrace();
				}
				lstView.setVisibility(View.GONE);
//				Toast.makeText(RegisterActivity.this, "Your Vote registered!!!", Toast.LENGTH_LONG ).show();
			}});
		

			
	}




	private void write(String text, Tag tag) throws IOException, FormatException {

		NdefRecord[] records = { createRecord(text) };
		NdefMessage  message = new NdefMessage(records);
		// Get an instance of Ndef for the tag.
		Ndef ndef = Ndef.get(tag);
		// Enable I/O
		ndef.connect();
		// Write the message
		ndef.writeNdefMessage(message);
		// Close the connection
		ndef.close();
	}



	private NdefRecord createRecord(String text) throws UnsupportedEncodingException {
		String lang       = "en";
		byte[] textBytes  = text.getBytes();
		byte[] langBytes  = lang.getBytes("US-ASCII");
		int    langLength = langBytes.length;
		int    textLength = textBytes.length;
		byte[] payload    = new byte[1 + langLength + textLength];

		// set status byte (see NDEF spec for actual bits)
		payload[0] = (byte) langLength;

		// copy langbytes and textbytes into payload
		System.arraycopy(langBytes, 0, payload, 1,              langLength);
		System.arraycopy(textBytes, 0, payload, 1 + langLength, textLength);

		NdefRecord recordNFC = new NdefRecord(NdefRecord.TNF_WELL_KNOWN,  NdefRecord.RTD_TEXT,  new byte[0], payload);

		return recordNFC;
	}


	@Override
	protected void onNewIntent(Intent intent){
		if(NfcAdapter.ACTION_TAG_DISCOVERED.equals(intent.getAction())){
			mytag = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);    
			Toast.makeText(this, "detected:" + mytag.toString(), Toast.LENGTH_SHORT ).show();
		}
	}

	@Override
	public void onPause(){
		super.onPause();
		WriteModeOff();
	}

	@Override
	public void onResume(){
		super.onResume();
		WriteModeOn();
	}

	private void WriteModeOn(){
		writeMode = true;
		adapter.enableForegroundDispatch(this, pendingIntent, writeTagFilters, null);
	}

	private void WriteModeOff(){
		writeMode = false;
		adapter.disableForegroundDispatch(this);
	}
	
	class stableArrayAdapter extends ArrayAdapter<String> {


		public stableArrayAdapter(Context context, int textViewResourceId, ArrayList<String> target) 
		{
			super(context, textViewResourceId, target);

		}

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return Target.size();
		}

		@Override
		public String getItem(int position) {
			// TODO Auto-generated method stub
			return Target.get(position);
		}

		@Override
		public int getPosition(String item) {
			// TODO Auto-generated method stub
			return super.getPosition(item);
		}

		@Override
		public boolean hasStableIds() {
			return true;
		}

	} 

}



